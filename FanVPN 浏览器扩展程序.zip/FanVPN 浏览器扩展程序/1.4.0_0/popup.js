const mainPage  = document.getElementById('mainPage');
const nodePage  = document.getElementById('nodePage');
const connectBtn= document.getElementById('connectBtn');
const ring3     = document.getElementById('ring3');
const ring2     = document.getElementById('ring2');
const ring1     = document.getElementById('ring1');
const statusPill= document.getElementById('statusPill');
const statusDot = document.getElementById('statusDot');
const statusText= document.getElementById('statusText');
const heroTitle = document.getElementById('heroTitle');
const heroSub   = document.getElementById('heroSub');
const nodeFlag  = document.getElementById('nodeFlag');
const nodeName  = document.getElementById('nodeName');
const nodeSub   = document.getElementById('nodeSub');
const switchBtn = document.getElementById('switchBtn');
const nodeCard  = document.getElementById('nodeCard');
const shieldPath= document.getElementById('shieldPath');
const checkPath = document.getElementById('checkPath');
const backBtn   = document.getElementById('backBtn');
const refreshBtn= document.getElementById('refreshBtn');
const nodeList  = document.getElementById('nodeList');

let allNodes = [];

function setShieldColor(color) {
  shieldPath.setAttribute('stroke', color);
  checkPath.setAttribute('stroke', color);
}

function setUI(state, node) {
  if (state === 'idle') {
    connectBtn.className = '';
    ring3.className = 'ring3'; ring2.className = 'ring2'; ring1.className = 'ring1';
    statusPill.style.border = '1.5px solid #c8dff8';
    statusDot.style.background = '#c8dff8';
    statusText.style.color = '#8ab4d8'; statusText.textContent = '未连接';
    heroTitle.style.color = '#b8d4f0'; heroTitle.textContent = '点击连接';
    heroSub.textContent = '安全访问全球网络';
    nodeFlag.className = 'flag-box';
    nodeSub.className = 'node-sub'; nodeSub.textContent = '自动选择';
    switchBtn.textContent = '选择 ›';
    setShieldColor('#c0d8f0');
    document.body.style.background = 'linear-gradient(160deg, #e8f3ff 0%, #dceeff 100%)';

  } else if (state === 'connecting') {
    connectBtn.className = 'connecting';
    ring3.className = 'ring3'; ring2.className = 'ring2'; ring1.className = 'ring1';
    statusPill.style.border = '1.5px solid #f0d890';
    statusDot.style.background = '#e8a020';
    statusText.style.color = '#b87800'; statusText.textContent = '连接中';
    heroTitle.style.color = '#b8d4f0'; heroTitle.textContent = '正在连接…';
    heroSub.textContent = '请稍候';
    nodeFlag.className = 'flag-box';
    nodeSub.className = 'node-sub'; nodeSub.textContent = '检测节点中';
    switchBtn.textContent = '';
    setShieldColor('#e8a020');
    document.body.style.background = 'linear-gradient(160deg, #e8f3ff 0%, #dceeff 100%)';

  } else if (state === 'connected') {
    connectBtn.className = 'connected';
    ring3.className = 'ring3 on pulse'; ring2.className = 'ring2 on pulse'; ring1.className = 'ring1 on';
    statusPill.style.border = '1.5px solid #0088cc';
    statusDot.style.background = '#0088cc';
    statusText.style.color = '#0088cc'; statusText.textContent = '已连接';
    heroTitle.style.color = '#0d2d50'; heroTitle.textContent = '连接成功';
    heroSub.textContent = '';
    nodeFlag.className = 'flag-box active';
    nodeSub.className = 'node-sub active'; nodeSub.textContent = '线路畅通';
    switchBtn.textContent = '切换 ›';
    setShieldColor('#0088cc');
    document.body.style.background = 'linear-gradient(160deg, #ddf0ff 0%, #c4e4ff 100%)';

    if (node) {
      nodeFlag.textContent = node.flag || 'US';
      nodeName.textContent = node.name || '美国·01';
    }
  }
}

function doConnect(node) {
  setUI('connecting', node);
  chrome.runtime.sendMessage({ action: 'connect', node: node || null }, (result) => {
    if (result && result.success) {
      setUI('connected', result.node);
    } else {
      setUI('idle');
      heroTitle.textContent = '连接失败，请重试';
      heroSub.textContent = '请检查网络后重试';
    }
  });
}

// 初始化：读取状态和上次节点名
chrome.runtime.sendMessage({ action: 'getStatus' }, (res) => {
  if (res && res.connected) {
    setUI('connected', res.activeNode);
  } else {
    setUI('idle');
    // 读取节点并显示，失败时自动重试
    let retryCount = 0;

    function updateNodeDisplay() {
      chrome.storage.local.get(['lastNode'], (data) => {
        chrome.runtime.sendMessage({ action: 'getNodes' }, (r) => {
          const nodes = r.nodes || [];

          if (nodes.length === 0) {
            retryCount++;
            nodeFlag.textContent = '?';
            nodeName.textContent = retryCount < 3 ? '获取节点中…' : '暂无法获取节点';
            if (retryCount < 3) {
              setTimeout(updateNodeDisplay, 5000);
            }
            return;
          }

          retryCount = 0;

          if (!data.lastNode) {
            // 首次安装，显示第一个节点
            const first = nodes[0];
            nodeFlag.textContent = first.flag || 'US';
            nodeName.textContent = first.name;
            return;
          }

          const last = nodes.find(n => n.server === data.lastNode);
          if (last) {
            // 找到上次节点
            nodeFlag.textContent = last.flag || 'US';
            nodeName.textContent = last.name;
          } else {
            // 上次节点已不存在
            nodeFlag.textContent = '?';
            nodeName.textContent = '自动选择';
            chrome.storage.local.remove(['lastNode']);
          }
        });
      });
    }

    updateNodeDisplay();
  }
});

connectBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'getStatus' }, (res) => {
    if (res && res.connected) {
      setUI('idle');
      chrome.runtime.sendMessage({ action: 'disconnect' });
    } else {
      doConnect(null);
    }
  });
});

nodeCard.addEventListener('click', () => {
  showNodePage();
});

function showNodePage() {
  mainPage.style.display = 'none';
  nodePage.style.display = 'block';
  loadNodeList();
}

function hideNodePage() {
  nodePage.style.display = 'none';
  mainPage.style.display = 'block';
}

backBtn.addEventListener('click', hideNodePage);

function loadNodeList() {
  chrome.runtime.sendMessage({ action: 'getNodes' }, (res) => {
    allNodes = res.nodes || [];
    renderNodeList(allNodes.map(n => ({ ...n, status: null })));
  });
}

function checkNodes() {
  renderNodeList(allNodes.map(n => ({ ...n, status: 'checking' })));
  chrome.runtime.sendMessage({ action: 'checkNodes' }, (res) => {
    if (res && res.results) renderNodeList(res.results);
  });
}

refreshBtn.addEventListener('click', checkNodes);

function renderNodeList(nodes) {
  chrome.runtime.sendMessage({ action: 'getStatus' }, (res) => {
    const activeServer = res && res.activeNode ? res.activeNode.server : null;
    nodeList.innerHTML = '';
    nodes.forEach(node => {
      const item = document.createElement('div');
      item.className = 'node-item' + (node.status === 'fail' ? ' disabled' : '');

      const siClass = node.status === 'ok'       ? 'si si-ok' :
                      node.status === 'slow'     ? 'si si-slow' :
                      node.status === 'fail'     ? 'si si-fail' :
                      node.status === 'checking' ? 'si si-checking' : '';

      const statusLabel = node.status === 'ok'       ? '正常' :
                          node.status === 'slow'     ? '较慢' :
                          node.status === 'fail'     ? '不可用' :
                          node.status === 'checking' ? '检测中…' : '';

      const statusColor = node.status === 'ok'   ? '#0088cc' :
                          node.status === 'slow' ? '#e8a020' :
                          node.status === 'fail' ? '#e04040' : '#a0c4e0';

      const isActive = node.server === activeServer;
      const flagActive = isActive ? ' active' : '';

      item.innerHTML = `
        <div class="item-left">
          <div class="item-flag${flagActive}">${node.flag || 'US'}</div>
          <div>
            <div class="item-name">${node.name}</div>
            ${siClass ? `<div class="item-status" style="color:${statusColor}">${statusLabel}</div>` : ''}
          </div>
        </div>
        <div class="item-right">
          ${siClass ? `<span class="${siClass}"></span>` : ''}
          ${isActive ? '<div class="check-on"></div>' : '<div class="check-off"></div>'}
        </div>
      `;

      if (node.status !== 'fail') {
        item.addEventListener('click', () => {
          hideNodePage();
          doConnect(node);
        });
      }
      nodeList.appendChild(item);
    });
  });
}
